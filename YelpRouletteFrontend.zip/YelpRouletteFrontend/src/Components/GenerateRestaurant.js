import React, {useState} from 'react';
import Button from 'react-bootstrap/Button';
import '../App.css';

var text = 'Click button to generate restaurant (text1)';
var text2 = 'Click button to generate restaurant (text2)';
const restaurant = ['Starbucks', 'McDonalds', 'Wendys', 'Subway', 'Red Lobster', 'Red Robin'];

const GenerateRestaurant = () => 
{

  const [address, setAddress] = useState('');
  const [radius, setRadius] = useState('');
  const [buttonText, setText] = useState(text);

  const changeAddress = event => 
  {
    setAddress(event.target.value);
  }

  const changeRadius = event => 
  {
    setRadius(event.target.value);
  }

  const clearFields = () => 
  {
    setAddress('');
    setRadius('');
  }

  fetch('/api/randomRestaurant')
      .then(response => response.text())
      .then(message => {
          text2 = message;
      });

  function generate() 
  {
    var num = Math.floor(Math.random() * restaurant.length);
    text = ('#' + (num+1) + '. ' + restaurant[num]);
    //alert('#' + (num+1) + '. ' + restaurant[num]);
  }

  return (
    <div>
      <label id="filterTitle">Filters</label>
      <label id="addressLabel">Address:</label>
      <input 
        type="text" 
        id="inputAddress"
        name="address" 
        size="20"
        onChange={changeAddress}
        value={address}/>
      <br></br>

      <label id="radiusLabel">Radius:</label>
      <input 
        type="number" 
        id="inputRadius"
        name="radius"
        step="1" 
        size="1"
        onChange={changeRadius}
        value={radius}
        required maxLength="3" />
      <br></br>

      <label id="veganLabel">Vegan?</label>

      <input 
        type="radio" 
        id="yesVegan"
        value="Yes"
        name="vOption"/>
      <label id="yesVeganLabel">Yes</label>

      <input 
        type="radio" 
        id="noVegan"
        value="No"
        name="vOption"/>
      <label id="noVeganLabel">No</label>

      <Button id="clearbtn" active size="lg" onClick={clearFields}>Clear Fields</Button>

      <Button id="generatebtn" variant="success" active size="lg" onClick={() => {
        generate();   //Test function that uses hardcoded array of strings
        setText(text2);
      }}>Generate Restaurant</Button>
      <h2>{text}</h2>
      <h2>{text2}</h2>
    </div>
  );
};

export default GenerateRestaurant