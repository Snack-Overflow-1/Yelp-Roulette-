import React from 'react'
import {Button} from './Button';
import './UserAccount.css';
import './w3CSS.css';

var inputs = [];  //[username, password];
var userExists = false;

const UserAccount = () =>
{
  async function getUserInfo()
  {
    inputs = [
    document.getElementById("inputUsername").value,         //0
    document.getElementById("inputPassword").value];        //1

    var jsonData = {
      "email" : inputs[0], // This is the username
      "password" : inputs[1],
      "firstName" : "",
      "lastName" : ""
    }

    //send user/pass to backend
    fetch("http://localhost:8080/api/register", {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(jsonData)
    })

    console.log("before userexist: " + userExists)

    //check if user exists in database
    fetch("http://localhost:8080/api/userExists", { 
    })
    .then(response => response.text())
    .then((bool) => {
      userExists = bool
      console.log(userExists)
      if(bool === "true"){
        alert("User exists already")

        
        //check password of existing user
        fetch("http://localhost:8080/api/getUser", { 
        })
        .then(response => response.text())
        .then((password) => {
          console.log(password);
          if(inputs[1] === password){
            alert("Password matches")
          }
          else{
            alert("Password no match :(")
          }
        })
        .catch((err) => {console.log(err.message)});
        
      }
      else{
        alert("User created")
      }
    })
    .catch((err) => {
      console.log(err.message)});


  }

  return (
    <div class='user-login'>
      <div class="w3-container">
          <p id="header-text">Login to an existing account, or create a new one.</p>
        
          <input 
            type="text" 
            id="inputUsername"
            name="username" 
            size="30"
            placeholder="Username"
            required
          />

          <br></br>
          <br></br>

          <input 
            type="text" 
            id="inputPassword"
            name="password" 
            size="30"
            placeholder="Password"
            required
          />

          <br></br>
          <br></br>

          <button id="loginbtn" onClick = {getUserInfo}>Login</button>
        </div>
    </div>
  )
}

export default UserAccount

