import React from 'react'
import UserAccount from '../UserAccount'

function Login() {
  return (
    <div>
      <body>
      <UserAccount/>
      </body>
    </div>
  )
}

export default Login