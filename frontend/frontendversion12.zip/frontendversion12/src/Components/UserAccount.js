import React from 'react'
import {Button} from './Button';
import './UserAccount.css';

var inputs = [];  //[username, password];

const UserAccount = () =>
{
  function getUserInfo()
  {
    inputs = [
    document.getElementById("inputUsername").value,      //1
    document.getElementById("inputPassword").value];       //2

    var jsonData = {
      "email" : inputs[1], // This is the username
      "password" : inputs[2],
    }

    fetch("http://localhost:8080/api/register", {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(jsonData)
    })
  }


  return (
    <div className='user-login'>
        <p id="header-text">Login to an existing account, or create a new one.</p>
        <input 
          type="text" 
          id="inputUsername"
          name="username" 
          size="30"
          placeholder="Username"
          required
        />

        <br></br>
        <br></br>

        <input 
          type="text" 
          id="inputPassword"
          name="password" 
          size="30"
          placeholder="Password"
          required
        />

        <br></br>

        <Button id="loginbtn" onClick = {getUserInfo} active size="lg">Login</Button>
    </div>
  )
}

export default UserAccount

