import React, {useState} from 'react';
import Button from 'react-bootstrap/Button';
import '../App.css';
import {Button as Button2} from './Button';
import './GenerateRestaurant.css';
import {addRecent, addFavorite} from "./pages/Favorites";

var apiRestaurants = [''];
var chosenRestaurant, restaurantNum, businesses;
const prices = ['$', '$$', '$$$', '$$$$'];
//const apiKey = 'aUUmAi731yi0X2gIQR2Y8ACDhPJSuPP6Y9Zsbn9stSBmluwa0vHYDYKh-HDYIcg4yPWhZ9FAwnYiXOCY2iI43ODZb7YFH5Ul6Mp1FB1GSWaPBvHfxQub3XGbi6BYY3Yx';
var inputs = [];  //[name, address, radius, price, vegan, open];
var curBusiness;

const GenerateRestaurant = () => 
{
  // const [radius, setRadius] = useState('');
  // const [buttonText, setText] = useState(text);
  const [errorText, setErrorText] = useState('');
  const [divRestaurants, setRestaurants] = useState(<div>Enter Address and Spin!</div>);
  const [address, setAddress] = useState('');
  const [price, setPrice] = useState('');
  const [phone, setPhone] = useState('');
  const [rating, setRating] = useState(0.0);
  const [time, setTime] = useState('');
  const [url, setURL] = useState('');
  const [imageURL, setImageURL] = useState('/images/food_placeholder.png');

  const clearFields = () => 
  {
    document.getElementById("inputAddress").value = '';
    document.getElementById("inputRadius").value = '';
    document.getElementById("inputPrice").value = '';
    document.getElementById("inputVegan").checked = false;
    document.getElementById("inputOpenNow").checked = false;
  }

  function getApiData(){
    inputs = [chosenRestaurant,                         //0
    document.getElementById("inputAddress").value,      //1
    document.getElementById("inputRadius").value,       //2
    document.getElementById("inputPrice").value,        //3
    document.getElementById("inputVegan").checked,      //4
    document.getElementById("inputOpenNow").checked];   //5

    //Send data to backend
    var jsonData = {
      "address" : inputs[1],
      "radius" : inputs[2],
      "price" : inputs[3],
      "openNow" : inputs[5]
    }
    fetch("http://ec2-34-222-81-234.us-west-2.compute.amazonaws.com:8080/api/input", {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(jsonData)
    })


    // Cannot fetch from frontend code unfortunately...

    // var apiURL = 'https://api.yelp.com/v3/businesses/search?location=' + inputs[1]
    // if(inputs[2] !== "") apiURL += '&radius=' + inputs[2];
    // if(inputs[3] !== "") apiURL += '&price=' + inputs[3];
    // if(inputs[5] !== false) apiURL += '&open_now=' + inputs[5];

    //Get api data from yelp business search endpoint
    fetch("http://ec2-34-222-81-234.us-west-2.compute.amazonaws.com:8080/api/getURL", { 
      //headers: {'Authorization': 'Bearer ' + apiKey}
    })
    .then(response => response.json())
    .then((apiData) => {
      for(var i = 0; i < apiData.businesses.length; i++){
        apiRestaurants[i] = apiData.businesses[i].name;
      }
      businesses = apiData.businesses;
      setRestaurants(divArray(apiRestaurants))
    })
    .catch((err) => {console.log(err.message)});
  }


  function debug() 
  {
    // var num = Math.floor(Math.random() * restaurant.length);
    // text = ('Test1(Hardcoded frontend) #' + (num+1) + '. ' + restaurant[num]);
    //alert('#' + (num+1) + '. ' + restaurant[num]);
    console.log(document.getElementById('display'));
    console.log(document.getElementById('container'));
    console.log(document.getElementById('container').children[0]);
    console.log("Generated");
    getApiData();
  }

  //inserts divs for each element in an array
  function divArray(array){
    var result = [];
    
    for(var i = 0; i < array.length; i++){
      result[i] = <div> {array[i]} </div>;
    }

    return result;
  }

  /* SLOT ANIMATION CODE */
  let hovering = false;

  function slotText(){
    if(hovering) return;
    setTimeout(() => hovering = false, 500);
    moveContainer();
    hovering = true;
  }

  function moveContainer () {
    let choosenOption = getRandomOption();
    setTop(-choosenOption.offsetTop + 2);
  }

  function setTop (top) {
    document.getElementById('container').style.top = `${top}px`;
  }

  function getRandomOption () {
    let options = document.getElementById('container').children;
    let randomOption = Math.floor(Math.random() * (options.length));
    chosenRestaurant = apiRestaurants[randomOption];
    restaurantNum = randomOption;
    let choosenOption = options[randomOption];
    //console.log(randomOption);
      
    return choosenOption;
  }
  /* END SLOT ANIMATION CODE */

  function printInput(){
    //exception checks
    // if(inputs[1].length === 0){
    //   console.log("EXCEPTION: Address Empty!");
    //   return false;
    // }
    if(inputs[2] > 40000){
      console.log("EXCEPTION: Radius too large!")
      inputs[2] = 40000;
      document.getElementById("inputRadius").value = 40000;
    }
    else if(inputs[2] < 1){
      console.log("EXCEPTION: Radius too small!")
      inputs[2] = null;
      document.getElementById("inputRadius").value = '';
    }

    inputs[0] = chosenRestaurant;
    console.log("Restaurant: " + inputs[0]);
    console.log("Address: " + inputs[1]);
    console.log("Radius: " + inputs[2] + "mi," + milesToMeters(inputs[2]) + "m");
    console.log("Price: " + inputs[3]);
    console.log("Vegan: " + inputs[4]);
    console.log("Open Now: " + inputs[5]);
    console.log(inputs);

    return true;
  }

  function milesToMeters(miles) {
    return miles * 1609.344;
  }

  function updateInfo(){
    //address
    curBusiness = businesses[restaurantNum];
    setAddress(curBusiness.location.address1 + ', ' + curBusiness.location.city + ', ' + curBusiness.location.zip_code);

    //price
    switch(curBusiness.price){
      case '$' : setPrice('$ (under $10)'); break;
      case '$$' : setPrice('$$ ($11 - $30)'); break;
      case '$$$' : setPrice('$$$ ($31 - $60)'); break;
      case '$$$$' : setPrice('$$$$ (over $60)'); break;
      default : setPrice('Prices not found');
    }

    //phone
    setPhone(curBusiness.display_phone);

    //rating
    setRating(curBusiness.rating);

    //yelp url
    setURL(curBusiness.url);

    //image url
    setImageURL(curBusiness.image_url);

    //add to recents
    addRecent(curBusiness);

  }

  return (
    <div>
      <div class="filter">
        <input 
          type="text" 
          id="inputAddress"
          name="address" 
          size="30"
          placeholder="Address"
          required
          />

        <input 
          type="number" 
          id="inputRadius"
          name="radius"
          placeholder="Radius"
          min = "1"
          max = "99"
          />

        <select name="prices" id="inputPrice">
          <option value="" selected hidden>Price</option>
          <option value={1}>{prices[0]}</option>
          <option value={2}>{prices[1]}</option>
          <option value={3}>{prices[2]}</option>
          <option value={4}>{prices[3]}</option>
        </select>

        <div id="checkBoxes">
        <input 
          type="checkbox" 
          id="inputVegan"
          value="vegan"
          name="vegan"/>
        <label for="vegan">Vegan</label>

        <input 
          type="checkbox" 
          id="inputOpenNow"
          value="openNow"
          name="openNow"/>
        <label for="openNow">Open Now</label>
        </div>
      </div>

      <br></br>
      <p id="errorText">{errorText}</p>

      <Button id="clearbtn" active size="lg" onClick={clearFields}>Clear Fields</Button>

      <Button2 className='spinbtn' buttonStyle='btn--primary' buttonSize='btn--large' onClick={() => {
          if(document.getElementById("inputAddress").value !== ''){
            getApiData()
            slotText()
            setErrorText("");
            printInput();
            updateInfo();
          }
          else{
            console.log("EXCEPTION: Address Empty!");
            setErrorText("Please enter an address.")
            alert("Please enter an address.")
          };
      }}> Spin! <i class="fa-solid fa-arrows-spin"/></Button2>

      <Button2 className='favoritebtn' buttonStyle='btn--outline' buttonSize='btn--large' onClick={() => {
        addFavorite(curBusiness)
      }}> Add to Favorites <i class="fa-regular fa-heart"/></Button2>
      
      <br></br>
      
      <section id="display">
        <div id="container">
            {divRestaurants}
        </div>
      </section>

      <div class='restaurantInfo'>
        <img src={imageURL} alt="restaurantImage" class='image'/>
        <p class='info'>
          <p class='box'><i class="fa-solid fa-location-pin fa-l fa-fw"/> {address} </p>
          <p class='box'><i class="fa-solid fa-tag fa-l fa-fw"></i> {price} </p>
          <p class='box'><i class="fa-sharp fa-solid fa-square-phone fa-l fa-fw"/> {phone} </p>
        </p>
        <p class='rating'>
          <p class='box'>Rating: {rating}/5 </p>
          <p class='box'>Open 11:00 AM - 10:00 PM</p>
          <p class='box'><i class="fa-solid fa-globe fa-fw"/>  <a href={url}>Yelp Link</a></p>
        </p>
        <p class='dishPhotos'>
          <img src="https://s3-media2.fl.yelpcdn.com/bphoto/PwZENcqawD_hhkptkBD0dA/o.jpg" alt="restaurantImage" class='dishImage'/>
          <img src="https://s3-media4.fl.yelpcdn.com/bphoto/Fdqrj_h6XwZ5dF5Y7NOhWw/o.jpg" alt="restaurantImage" class='dishImage'/>
          <img src="https://s3-media3.fl.yelpcdn.com/bphoto/MQsE-xbVkDKX4x1-_865ng/o.jpg" alt="restaurantImage" class='dishImage'/>
        </p>
      </div>

      <br></br><br></br>

    </div>
  );
};

export default GenerateRestaurant

