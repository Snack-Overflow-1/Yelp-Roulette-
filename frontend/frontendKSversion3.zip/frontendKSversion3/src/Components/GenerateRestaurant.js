import React, {useState} from 'react';
import Button from 'react-bootstrap/Button';
import '../App.css';
import {Button as Button2} from './Button';
import './GenerateRestaurant.css';

// var text = 'Click button to generate restaurant (text1)';
// var text2 = 'Click button to generate restaurant (text2)';
const restaurant = ['Phox', 'Starbucks', 'McDonalds', 'Wendys', 'Subway', 'Red Lobster', 'Red Robin', 'In n Out', 'Smash Burger', 'Five Guys'];
var chosenRestaurant;
const price = ['$', '$$', '$$$', '$$$$'];

const GenerateRestaurant = () => 
{
  // const [address, setAddress] = useState('');
  // const [radius, setRadius] = useState('');
  // const [buttonText, setText] = useState(text);
  const [errorText, setErrorText] = useState('');

  // const changeAddress = event => 
  // {
  //   setAddress(event.target.value);
  // }

  // const changeRadius = event => 
  // {
  //   setRadius(event.target.value);
  // }

  const clearFields = () => 
  {
    // setAddress('');
    // setRadius('');
    document.getElementById("inputAddress").value = '';
    document.getElementById("inputRadius").value = '';
    document.getElementById("inputPrice").value = '';
    document.getElementById("inputVegan").checked = false;
    document.getElementById("inputOpenNow").checked = false;
  }

  fetch('/api/randomRestaurant')
      .then(response => response.text())
      .then(message => {
          // text2 = message;
      });

  function generate() 
  {
    // var num = Math.floor(Math.random() * restaurant.length);
    // text = ('Test1(Hardcoded frontend) #' + (num+1) + '. ' + restaurant[num]);
    //alert('#' + (num+1) + '. ' + restaurant[num]);
    console.log(document.getElementById('display'));
    console.log(document.getElementById('container'));
    console.log(document.getElementById('container').children[0]);
    console.log("Generated");
  }

  //inserts divs for each element in an array
  function divArray(array){
    var result = [];
    
    for(var i = 0; i < array.length; i++){
      result[i] = <div> {array[i]} </div>;
    }

    return result;
  }

  return (
    <div>
      <div class="filter">
        <input 
          type="text" 
          id="inputAddress"
          name="address" 
          size="30"
          placeholder="Address"
          required
          />

        <input 
          type="number" 
          id="inputRadius"
          name="radius"
          placeholder="Radius"
          min = "1"
          max = "999"
          />

        <select name="price" id="inputPrice">
          <option value="" selected hidden>Price</option>
          <option value={price[0]}>{price[0]}</option>
          <option value={price[1]}>{price[1]}</option>
          <option value={price[2]}>{price[2]}</option>
          <option value={price[3]}>{price[3]}</option>
        </select>

        <input 
          type="checkbox" 
          id="inputVegan"
          value="vegan"
          name="vegan"/>
        <label for="vegan">Vegan</label>

        <input 
          type="checkbox" 
          id="inputOpenNow"
          value="openNow"
          name="openNow"/>
        <label for="openNow">Open Now</label>
      </div>

      <br></br>
      <p id="errorText">{errorText}</p>
      <Button2 className='spinbtn' buttonStyle='btn--primary' buttonSize='btn--large' onClick={() => {
          if(printInput()){
            slotText()
            setErrorText("");
          }
          else{
            setErrorText("Please enter an address")
            alert("Please enter an address")
          };
      }}> Spin! <i class="fa-solid fa-arrows-spin"/></Button2>

      <br></br>
      
      <section id="display">
        <div id="container">
            {divArray(restaurant)}
        </div>
      </section>
      
      <div class='restaurantInfo'>
        <img src="https://s3-media2.fl.yelpcdn.com/bphoto/PwZENcqawD_hhkptkBD0dA/o.jpg" alt="restaurantImage" class='image'/>
        <p class='info'>
          <p class='box'><i class="fa-solid fa-location-pin fa-l fa-fw"/> 3530 W Temple Ave, Ste B, Pomona, CA 91768</p>
          <p class='box'><i class="fa-solid fa-tag fa-l fa-fw"></i> $ $ ($11-$30)</p>
          <p class='box'><i class="fa-sharp fa-solid fa-square-phone fa-l fa-fw"/> (714) 203-4100</p>
        </p>
        <p class='rating'>
          <p class='box'>Rating: 4.5/5 </p>
          <p class='box'>Open 11:00 AM - 10:00 PM</p>
          <p class='box'><i class="fa-solid fa-globe fa-fw"/>  <a href="https://www.yelp.com/biz/phox-pomona-3?adjust_creative=lctkDJ_2emDgN4knWyWhDg&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_search&utm_source=lctkDJ_2emDgN4knWyWhDg">Yelp Link</a></p>
        </p>
        <p class='dishPhotos'>
          <img src="https://s3-media2.fl.yelpcdn.com/bphoto/PwZENcqawD_hhkptkBD0dA/o.jpg" alt="restaurantImage" class='dishImage'/>
          <img src="https://s3-media4.fl.yelpcdn.com/bphoto/Fdqrj_h6XwZ5dF5Y7NOhWw/o.jpg" alt="restaurantImage" class='dishImage'/>
          <img src="https://s3-media3.fl.yelpcdn.com/bphoto/MQsE-xbVkDKX4x1-_865ng/o.jpg" alt="restaurantImage" class='dishImage'/>
        </p>
      </div>

      <br></br><br></br>
      
      <Button id="clearbtn" active size="lg" onClick={clearFields}>Clear Fields</Button>

      <Button id="generatebtn" variant="success" active size="lg" onClick={() => {
        //generate();     //Test function that uses hardcoded array of strings
        //setText(text2);
        generate();
        printInput()
      }}>Debug Button</Button>

      <br></br><br></br>

    </div>
  );
};

export default GenerateRestaurant

let hovering = false;

function slotText(){
  if(hovering) return;
  setTimeout(() => hovering = false, 500);
  moveContainer();
  hovering = true;
}

function moveContainer () {
  let choosenOption = getRandomOption();
  setTop(-choosenOption.offsetTop + 2);
}

function setTop (top) {
  document.getElementById('container').style.top = `${top}px`;
}

function getRandomOption () {
  let options = document.getElementById('container').children;
  let randomOption = Math.floor(Math.random() * (options.length));
  chosenRestaurant = restaurant[randomOption];
  let choosenOption = options[randomOption];
    
  return choosenOption;
}

function printInput(){
  var inputs = [chosenRestaurant,                       //0
    document.getElementById("inputAddress").value,      //1
    document.getElementById("inputRadius").value,       //2
    document.getElementById("inputPrice").value,        //3
    document.getElementById("inputVegan").checked,      //4
    document.getElementById("inputOpenNow").checked];   //5

  //exception checks
  if(inputs[1].length === 0){
    console.log("EXCEPTION: Address Empty!");
    return false;
  }
  if(inputs[2] > 999){
    console.log("EXCEPTION: Radius too large!")
    inputs[2] = 999;
    document.getElementById("inputRadius").value = 999
  }
  else if(inputs[2] < 1){
    console.log("EXCEPTION: Radius too small!")
    inputs[2] = 5;
    document.getElementById("inputRadius").value = 5
  }

  console.log("Restaurant: " + inputs[0]);
  console.log("Address: " + inputs[1]);
  console.log("Radius: " + inputs[2]);
  console.log("Price: " + inputs[3]);
  console.log("Vegan: " + inputs[4]);
  console.log("Open Now: " + inputs[5]);

  return true;
}