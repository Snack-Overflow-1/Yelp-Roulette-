import React, {useState} from 'react';
import Button from 'react-bootstrap/Button';
import '../App.css';
import {Button as Button2} from './Button';

var text = 'Click button to generate restaurant (text1)';
var text2 = 'Click button to generate restaurant (text2)';
const restaurant = ['Starbucks', 'McDonalds', 'Wendys', 'Subway', 'Red Lobster', 'Red Robin', 'In n Out', 'Smash Burger', 'Five Guys'];
var chosenRestaurant;
const price = ['$', '$$', '$$$', '$$$$'];

const GenerateRestaurant = () => 
{
  // const [address, setAddress] = useState('');
  // const [radius, setRadius] = useState('');
  const [buttonText, setText] = useState(text);

  // const changeAddress = event => 
  // {
  //   setAddress(event.target.value);
  // }

  // const changeRadius = event => 
  // {
  //   setRadius(event.target.value);
  // }

  const clearFields = () => 
  {
    // setAddress('');
    // setRadius('');
    document.getElementById("inputAddress").value = '';
    document.getElementById("inputRadius").value = '';
    document.getElementById("inputPrice").value = '';
    document.getElementById("inputVegan").checked = false;
    document.getElementById("inputOpenNow").checked = false;
  }

  fetch('/api/randomRestaurant')
      .then(response => response.text())
      .then(message => {
          text2 = message;
      });

  function generate() 
  {
    // var num = Math.floor(Math.random() * restaurant.length);
    // text = ('Test1(Hardcoded frontend) #' + (num+1) + '. ' + restaurant[num]);
    //alert('#' + (num+1) + '. ' + restaurant[num]);
    console.log(document.getElementById('display'));
    console.log(document.getElementById('container'));
    console.log(document.getElementById('container').children[0]);
    console.log("Generated");
  }

  //inserts divs for each element in an array
  function divArray(array){
    var result = [];
    
    for(var i = 0; i < array.length; i++){
      result[i] = <div> {array[i]} </div>;
    }

    return result;
  }

  return (
    <div>
      <input 
        type="text" 
        id="inputAddress"
        name="address" 
        size="20"
        placeholder="Address"
        required
        />

      <input 
        type="number" 
        id="inputRadius"
        name="radius"
        placeholder="Radius"
        min = "1"
        max = "999"
        />

      <select name="price" id="inputPrice">
        <option value="" selected hidden>Price</option>
        <option value={price[0]}>{price[0]}</option>
        <option value={price[1]}>{price[1]}</option>
        <option value={price[2]}>{price[2]}</option>
        <option value={price[3]}>{price[3]}</option>
      </select>

      <container>
        <input 
          type="checkbox" 
          id="inputVegan"
          value="vegan"
          name="vegan"/>
        <label for="vegan">Vegan</label>

        <input 
          type="checkbox" 
          id="inputOpenNow"
          value="openNow"
          name="openNow"/>
        <label for="openNow">Open Now</label>
      </container>

      
      <br></br><br></br>
      
      <Button id="clearbtn" active size="lg" onClick={clearFields}>Clear Fields</Button>

      <Button id="generatebtn" variant="success" active size="lg" onClick={() => {
        //generate();     //Test function that uses hardcoded array of strings
        //setText(text2);
        generate();
      }}>Generate Restaurant</Button>

      <br></br><br></br>

      <Button2 className='spinbtn' buttonStyle='btn--primary' buttonSize='btn--large' onClick={() => {
          slotText();     
          printInput();
      }}> Spin! <i class="fa-solid fa-arrows-spin"/></Button2>

      <br></br><br></br>

      <section id="display">
        <div id="container">
            {divArray(restaurant)}
        </div>
      </section>
    </div>
  );
};

export default GenerateRestaurant

let hovering = false;

function slotText(){
  if(hovering) return;
  setTimeout(() => hovering = false, 500);
  moveContainer();
  hovering = true;
}

function moveContainer () {
  let choosenOption = getRandomOption();
  setTop(-choosenOption.offsetTop + 2);
}

function setTop (top) {
  document.getElementById('container').style.top = `${top}px`;
}

function getRandomOption () {
  let options = document.getElementById('container').children;
  let randomOption = Math.floor(Math.random() * (options.length));
  chosenRestaurant = restaurant[randomOption];
  let choosenOption = options[randomOption];
    
  return choosenOption;
}

function printInput(){
  var inputs = [chosenRestaurant,                       //0
    document.getElementById("inputAddress").value,      //1
    document.getElementById("inputRadius").value,       //2
    document.getElementById("inputPrice").value,        //3
    document.getElementById("inputVegan").checked,      //4
    document.getElementById("inputOpenNow").checked];   //5

  //exception checks
  if(inputs[1].length === 0){
    console.log("EXCEPTION: Address Empty!");
  }
  if(inputs[2] > 999){
    console.log("EXCEPTION: Radius too large!")
    inputs[2] = 999;
    document.getElementById("inputRadius").value = 999
  }
  else if(inputs[2] < 1){
    console.log("EXCEPTION: Radius too small!")
    inputs[2] = 1;
    document.getElementById("inputRadius").value = 1
  }

  console.log("Restaurant: " + inputs[0]);
  console.log("Address: " + inputs[1]);
  console.log("Radius: " + inputs[2]);
  console.log("Price: " + inputs[3]);
  console.log("Vegan: " + inputs[4]);
  console.log("Open Now: " + inputs[5]);

}