import React from 'react'
import {Button} from './Button';
import '../App.css';
import './HeroSection.css';

function HeroSection() {
  return (
    <div className='hero-container'>
        <img src="/images/restaurant1.jpg" alt="restaurant1"/>
        <h1>The search for your next meal starts here!</h1>
        <div classname="hero-btns">
            <Button className='btns' buttonStyle='btn--outline' buttonSize='btn--large'>
                Get Started
            </Button>
        </div>
    </div>
  )
}

export default HeroSection

