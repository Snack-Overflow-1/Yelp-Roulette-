import React from 'react'
import {Button} from './Button';
import '../App.css';
import './HeroSection.css';

function HeroSection() {
  return (
    <div className='hero-container'>
        <img src="/images/restaurant1.jpg" alt="restaurant1"/>
        <h1>TEXT GOES HERE</h1>
        <p>Scroll down to get started!</p>
        <div classname="hero-btns">
            <Button className='btns' buttonStyle='btn--outline' buttonSize='btn--large'>
                BUTTON1
            </Button>
            <Button className='btns' buttonStyle='btn--primary' buttonSize='btn--large'>
                BUTTON2 <i className='far fa-play-circle' />
            </Button>
        </div>
    </div>
  )
}

export default HeroSection

